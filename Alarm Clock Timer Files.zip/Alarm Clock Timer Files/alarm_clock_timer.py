'''This code runs a fully functioning timer on the users terminal/console. Timer can be set up to a max value by the user of 23:59:59 where format is in HH:MM:SS
Date Created: 2023/11/13
Creator: Don
'''

import datetime as dt
import time
from os import system
from time import sleep
from playsound import playsound


RESET = 59  # This is the value that our timer will reset too when a minute, second, hour etc. has passed
ALARM_SOUND = r"Radar Alarm Sound Effect.mp3"


def reset_func(hour: int, minute: int, second: int) -> tuple:
    '''Responsible for resetting corresponding units of time to 59 when 0 seconds is reached.
    '''
    global RESET
    
    if minute == 0 and hour == 0:
        pass  # Timer has elapsed, and function doesn't need to do anything
    elif minute == 0 and hour != 0:
        hour -= 1
        minute = RESET
    elif minute != 0:
        minute -= 1
    second = RESET    
    
    return hour, minute, second

def main() -> str:
    ''' Establishing alarm clock logic
    '''
    # Printing Alarm Clock banner
    system('cls')  # Clears console screen
    NAME = ' Alarm Clock Timer '
    print(f'{NAME:#^50}')
    
    
    # Asking user how many times they want the alarm bell to sound when timer is elapsed. This is necessary as code is run sequentially and sound must play fully before user can be asked for their next action
    while True:
        try:
            loops = int(input('# of Alarm Sounds When Timer Elapsed?: '))
            
            if loops > 5:
                answer = input(f'Warning: Loop will sound {loops} times before stopping. Confirm? (Yes or No)\n').upper()
                
                if answer == 'YES':
                    break
                elif answer == 'NO':
                    continue
                else:
                    print('Invalid response')
            elif loops <= 0:
                print('Invalid response. Loops must be positive non-zero integer only.')
                continue
            else:
                break
            
        except ValueError:
            print('Invalid input. Numerical response value accepted only')
    
    
    # Asking user for time they wish to set on timer
    print('Set desired time below.')
    while True:
        try:
            hour = int(input('Hour(s): '))
            minute = int(input('Minute(s): '))
            second = int(input('Second(s): '))
            
            if hour not in range(24):
                print('Invalid input. Hour value must be in range 0 - 23')
                continue
            elif minute not in range(60) or second not in range(60):
                print('Invalid input. Minute/second value must be in range 0 - 59')
                continue
            else:
                break
            
        except TypeError and ValueError:
            print('Invalid input. Only numerical values accepted.')
    
    
    # Logic that ammends the timer and displays new updated timer for each second delay
    total_seconds = ""  # Completely arbitrary value used as placeholder
    
    while total_seconds != 0:
        # Tracking elapsed time of code before sleep function implements delay. This will addresses the additional time needed to be offset because of code run time
        start_time = time.time()
        
        # Creating time object to display timer in a clock format
        clock_time = dt.time(hour, minute, second)
        
        # Clearing terminal/system console to update timer display without cluttering screen
        system('cls')
        
        # Printing updated timer to terminal/system console
        print(clock_time)
        
        # Checking for when seconds remaining reaches 0. If this is the case then reset_func must be called. Test case is also implemented for if user starts timer at 00:00:00, in which alarm sounds immediately.
        if second == 0 and minute == 0 and hour == 0:
            total_seconds = dt.timedelta(hours=hour, minutes=minute, seconds=second).total_seconds()
            break    
        elif second == 0 and (minute != 0 or hour != 0):
            hour, minute, second = reset_func(hour, minute, second)
        elif second != 0:
            second -= 1

        # Passing the time via seconds. Delay incorporates additional time taken to run preceding code before sleep func. 
        end_time = time.time()
        sleep(1 - (end_time - start_time))
        
        # Resetting total number of seconds remaining.
        total_seconds = dt.timedelta(hours=hour, minutes=minute, seconds=second).total_seconds()
    
    
    # Notifying user timer has finished with an alarm sound
    system('cls')
    print('{clock_time}: Timer Elapsed!'.format(clock_time = dt.time(hour, minute, second)))
    
    while total_seconds == 0 and loops !=0:
        print(f'Alarm will sound {loops} more time(s)...')        
        playsound(ALARM_SOUND)
        loops -= 1

    
    # Prompting user for timer reset or quit
    while True:
        response = input(f'Set timer again? (Yes or No)\n').upper()
        
        if response == 'YES' or response == 'NO':
            break
        else:
            print('Reponse Invalid.')
            continue
    return response


if __name__ == '__main__':
    response = main()
    
    # Re-running code if user responds yes to timer-reset
    while response == 'YES':
        response = main()

    
    
    





