'''Purpose of this function is to debug our alarm clock script. Making sure multiple test cases for varying values of hours, minutes, or seconds yield the correct output.
Date Created: 2023/11/13
Creator: Don
'''

import sys
from alarm_clock_timer import reset_func
import datetime

def assertion_test():
    '''Assertion tests for various values inputted into 'reset_func' function. Test case where hour, minute, and second all equate to 0 will be exempt in this unit test as that specific case never reaches the 'reset_func' function that is being tested here.
    '''
    
    # TEST CASE FOR n HOURS, 0 MINUTES, 0 SECONDS, where 1 <= n < 24
    for i in range(1, 24):
        hour, minute, second = reset_func(hour = i, minute = 0, second = 0)
        
        assert reset_func(hour = i, minute = 0, second = 0) == (i - 1, 59, 59), f'The yielded output when the function "reset_func" receives the time {datetime.time(hour = i, minute = 0, second = 0)} was {datetime.time(hour, minute, second)} when it should have been {datetime.time(hour = i - 1, minute = 59, second = 59)}.'
    
    # TEST CASE FOR 0 HOURS, n MINUTES, 0 SECONDS, where 1 <= n < 60
    for i in range(1, 60):
        hour, minute, second = reset_func(hour = 0, minute = i, second = 0)
        
        assert reset_func(hour = 0, minute = i, second = 0) == (0, i - 1, 59), f'The yielded output when the function "reset_func" receives the time {datetime.time(hour = 0, minute = i, second = 0)} was {datetime.time(hour, minute, second)} when it should have been {datetime.time(hour = 0, minute = i - 1, second = 59)}.'
 
    # TEST CASE FOR n HOURS, m MINUTES, 0 SECONDS, where 1 <= n < 24 and 1 <= m < 60
    for i in range(1, 24):
        for j in range(1, 60):
            hour, minute, second = reset_func(hour = i, minute = j, second = 0)
            
            if i == 0 and j == 0:  # This scenario is passed because it never reaches the reset_func function. Timer elapses immediately.
                pass
            elif i == 0 and j != 0:  # Scenario already tested above
                pass 
            elif i != 0 and j == 0:  # Scenario already tested above
                pass
            elif i != 0 and j != 0:
                assert reset_func(hour = i, minute = j, second = 0) == (i, j - 1, 59), f'The yielded output when the function "reset_func" receives the time {datetime.time(hour = i, minute = j, second = 0)} was {datetime.time(hour, minute, second)} when it should have been {datetime.time(hour = i, minute = j - 1, second = 59)}.'


if __name__ == '__main__':
    try: 
        assertion_test()
    except AssertionError as e:
        print(f'While running the debugger found an error.\n{e}')
    else:
        print('The corresponding function "reset_func" ran without any errors found.')